const mongoose = require("mongoose");

const certificateSchema = mongoose.Schema(
    {
        hrId: {
            type: mongoose.Schema.Types.ObjectId,
            required: true,
            ref: "User",
        },
        name: {
            type: String,
            required: true,
        },
        email: {
            type: String,
            required: true,
        },
        type: {
            type: String,
            required: true
        }
    },
    {
        timestamps: true,
    }
);


const Certificate = mongoose.model("Certificate", certificateSchema);

module.exports = Certificate;