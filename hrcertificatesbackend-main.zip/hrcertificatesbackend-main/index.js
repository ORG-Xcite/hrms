const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/config");
const generateCompletionPdf = require("./generatepdf/generateCompletionPdf");
const generateParticipationPdf = require("./generatepdf/generateParticipationPdf");
const generateAppreciationPdf = require("./generatepdf/generateAppreciationPdf");
const generateAppointmentPdf = require("./generatepdf/generateAppointmentPdf");
const generateLOR = require("./generatePdf/generateLOR")
const { protect } = require("./middlewares/protectedRoutes")
const cors = require("cors")
const Certificate = require("./models/certificateModel")
// Routes
const userRoutes = require("./routes/userRoutes");
const expressAsyncHandler = require("express-async-handler");
dotenv.config();

// Connecting to mongodb server
connectDB();

// express application
const app = express();

// allow CORS
app.use(cors());

// Body Parser middleware, no need to install body-parser package
app.use(express.json());

const PORT = process.env.PORT || 5000;

app.use("/user", userRoutes);

app.get("/", (req, res) => {
    res.send("HR Certificates backend is working")
})

















// CERTIFICATE CONTROLLERS

app.post("/sendCompletionCertificate", (req, res) => {
    // res.send("<h1>Welcome to Full Stack Simplified</h1>");
    // res.download("output.pdf");
    const { hrId, name, domain, date1, date2, email } = req.body
    //   console.log(req.params.name, req.params.course);
    Certificate.create({
        hrId, name, email, type: "completion"
    }).then(() => {
        console.log("Completion Certificate created");
        Certificate.find({ hrId, name, email, type: "completion" }).then((res) => {
            // console.log(res[0]._id)
            const certiId = res[0]._id
            generateCompletionPdf(certiId, name, domain, date1, date2, email);
        }).catch((err) => console.log(err))
    }).catch((err) => {
        console.log(err);
    })




    // generateCompletionPdf(name, domain, date1, date2, email);
    res.download("certificates");
});

app.post("/sendParticipationCertificate", (req, res) => {
    // res.send("<h1>Welcome to Full Stack Simplified</h1>");
    // res.download("output.pdf");
    const { hrId, name, email, sessiontype, title, date } = req.body
    Certificate.create({
        hrId, name, email, type: "participation"
    }).then(() => {
        console.log("Participation Certificate created");
        Certificate.find({ hrId, name, email, type: "participation" }).then((res) => {
            // console.log(res[0]._id)
            const certiId = res[0]._id
            generateParticipationPdf(certiId, name, email, sessiontype, title, date);
        }).catch((err) => console.log(err))
    }).catch((err) => {
        console.log(err);
    })
    //   console.log(req.params.name, req.params.course);
    // generateParticipationPdf(name, email, sessiontype, title, date);
    res.download("certificates");
});

app.post("/sendAppreciationCertificate", (req, res) => {
    // res.send("<h1>Welcome to Full Stack Simplified</h1>");
    // res.download("output.pdf");
    const { hrId, name, email, sessiontype, title, date } = req.body
    Certificate.create({
        hrId, name, email, type: "appreciation"
    }).then(() => {
        console.log("Appreciation Certificate created");
        Certificate.find({ hrId, name, email, type: "appreciation" }).then((res) => {
            // console.log(res[0]._id)
            const certiId = res[0]._id
            generateAppreciationPdf(certiId, name, email, sessiontype, title, date);
        }).catch((err) => console.log(err))
    }).catch((err) => {
        console.log(err);
    })
    //   console.log(req.params.name, req.params.course);
    // generateAppreciationPdf(name, email, sessiontype, title, date);
    res.download("certificates");
});

// res.send("<h1>Welcome to Full Stack Simplified</h1>");
// res.download("output.pdf");
//NOT WORKING
app.post("/sendAppointmentLetter", (req, res) => {
    const { hrId, name, email, role, hrsignurl, hrname, hrposition } = req.body
    Certificate.create({
        hrId, name, email, type: "appointment"
    }).then(() => {
        console.log("Appointment Certificate created");
        Certificate.find({ hrId, name, email, type: "appointment" }).then((res) => {
            // console.log(res[0]._id)
            const certiId = res[0]._id
            generateAppointmentPdf(certiId, name, email, role, hrsignurl, hrname, hrposition);
        }).catch((err) => console.log(err))
    }).catch((err) => {
        console.log(err);
    })
    //   console.log(req.params.name, req.params.course);
    // generateAppointmentPdf(name, email, role, hrsignurl, hrname, hrposition);
    res.download("certificates");
});
app.post("/sendLOR", (req, res) => {
    // res.send("<h1>Welcome to Full Stack Simplified</h1>");
    // res.download("output.pdf");
    const { hrId, name, email, domain, gender, hrsignurl, hrname, hrposition, date1, date2 } = req.body
    Certificate.create({
        hrId, name, email, type: "LOR"
    }).then(() => {
        console.log("LOR created");
        Certificate.find({ hrId, name, email, type: "LOR" }).then((res) => {
            // console.log(res[0]._id)
            const certiId = res[0]._id
            generateLOR(certiId, name, email, domain, gender, hrsignurl, hrname, hrposition, date1, date2);
        }).catch((err) => console.log(err))
    }).catch((err) => {
        console.log(err);
    })

    //   console.log(req.params.name, req.params.course);
    // generateLOR(name, email, domain, gender, hrsignurl, hrname, hrposition, date1, date2);
    res.download("certificates");
});

app.get("/getAllCertificates", async (req, res) => {
    const allCertificates = await Certificate.find().populate("hrId")
    if (allCertificates) {
        res.status(200).json({ data: allCertificates })
    } else {
        res.status(400).json({ error: "Couldn't find all certificates" })
    }
})






























// generatePDF("Raj Sanghavi", "HTML COURSE");

app.listen(process.env.PORT || 5000, () => {
    console.log(`Server is running on port ${PORT}.`);
});

// const express = require('express');
// const bodyParser = require('body-parser');
// const pdf = require('html-pdf');
// const cors = require('cors');

// const { completion } = require('./documents/index');

// const app = express();

// const port = process.env.PORT || 5000;

// app.use(cors());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

// app.post('/create-completion-pdf', (req, res) => {
//     const { name, domain, date1, date2 } = req.body
//     pdf.create(completion(req.body), {
//         "format": "A4",
//         "orientation": "landscape",
//         "border": "0",
//     }).toFile(`${name}_${domain}_completion_certificate.pdf`, (err) => {
//         if (err) {
//             res.send(Promise.reject());
//         }
//         res.send(Promise.resolve())
//         res.status(200).json({ "message": "PDF created successfully." })

//         console.log("pdf created");
//         // res.sendFile(`${__dirname}/${name}_${domain}_completion_certificate.pdf`)
//     });
// });

// // app.get('/fetch-completion-pdf', (req, res) => {
// //     res.sendFile(`${__dirname}/result.pdf`)
// // })

// app.listen(port, () => console.log(`Listening on port ${port}`));