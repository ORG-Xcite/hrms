const PDFDocument = require("pdfkit");
const fs = require("fs");
const nodemailer = require("nodemailer");
const QRCode = require('qrcode');
const axios = require("axios")

const generateParticipationPdf = async (certiId, name, email, sessiontype, title, date) => {
    const doc = new PDFDocument({
        layout: "landscape",
        size: "A4",
    });

    // Helper to move to next line
    function jumpLine(doc, lines) {
        for (let index = 0; index < lines; index++) {
            doc.moveDown();
        }
    }

    doc.pipe(fs.createWriteStream(`certificates/participation/${name}_${title}_participation_certificate.pdf`));

    doc.rect(0, 0, doc.page.width, doc.page.height).fill("#fff");

    doc.fontSize(10);

    // Margin
    const distanceMargin = 18;

    doc
        .fillAndStroke("#9d0000")
        .lineWidth(37)
        .lineJoin("butt")
        .rect(
            distanceMargin,
            distanceMargin,
            doc.page.width - distanceMargin * 2,
            doc.page.height - distanceMargin * 2
        )
        .stroke();

    // Header
    const maxWidth = 140;
    const maxHeight = 70;

    // doc.image("images/winners.png", doc.page.width / 2 - maxWidth / 2, 60, {
    //     fit: [maxWidth, maxHeight],
    //     align: "center",
    // });

    jumpLine(doc, 5);

    // doc
    //     .font("fonts/NotoSansJP-Light.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text("Super Course for Awesomes", {
    //         align: "center",
    //     });

    jumpLine(doc, 2);
    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(20)
        .fill("#021c27")
        .text(`XcitEducation 
Worldwide

`, 50, 50, {
            align: "left",
        });


    // Content
    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(20)
        .fill("#021c27")
        .text("CERTIFICATE OF PARTICPATION", {
            align: "center",
        });

    jumpLine(doc, 1);

    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(10)
        .fill("#021c27")
        .text("The certificate is awarded to :", {
            align: "center",
        });

    jumpLine(doc, 2);

    doc
        .font("fonts/NotoSansJP-Bold.otf")
        .fontSize(24)
        .fill("#021c27")
        .text(`${name}`, {
            align: "center",
        });

    jumpLine(doc, 1);
    const months = {
        0: "January",
        1: "February",
        2: "March",
        3: "April",
        4: "May",
        5: "June",
        6: "July",
        7: "August",
        8: "September",
        9: "October",
        10: "November",
        11: "December",
    };
    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(15)
        .fill("#021c27")
        .text(
            // `has successfully completed the ${course} on ${new Date(
            //   Date.now()
            // ).toLocaleDateString()}.`
            `for attending ${sessiontype} on ${title}. The session was conducted on ${date} by XcitEducation`,
            {
                align: "center",
            }
        );

    jumpLine(doc, 7);

    doc.lineWidth(1);

    // Signatures
    const lineSize = 154;
    const signatureHeight = 450;

    doc.fillAndStroke("#021c27");
    doc.strokeOpacity(0.2);

    const startLine1 = 208;
    const endLine1 = 198 + lineSize;
    doc
        .moveTo(startLine1, signatureHeight)
        .lineTo(endLine1, signatureHeight)
        .stroke();
    doc.image("images/xcitedulogo.jpg", startLine1 + 530, 50, {
        // fit: [100, 100],
        // align: "left",
        height: 50,
        width: 50,
    });
    doc.image("images/nancy.jpeg", startLine1 + 20, 370, {
        fit: [maxWidth, maxHeight],
        align: "left",
    });
    doc.image("images/yaamini1.jpeg", startLine1 + 330, 370, {
        fit: [300, 100],
        align: "left",
    });

    const startLine2 = endLine1;
    const endLine2 = startLine2 + lineSize;
    // doc
    //   .moveTo(startLine2, signatureHeight)
    //   .lineTo(endLine2, signatureHeight)
    //   .stroke();

    const startLine3 = endLine2;
    const endLine3 = startLine3 + lineSize;
    doc
        .moveTo(startLine3, signatureHeight)
        .lineTo(endLine3, signatureHeight)
        .stroke();

    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(10)
        .fill("#021c27")
        .text("Nancy", startLine1, signatureHeight + 10, {
            columns: 1,
            columnGap: 0,
            height: 40,
            width: lineSize,
            align: "center",
        });
    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(10)
        .fill("#021c27")
        .text("HR HEAD, XcitEducation", startLine1, signatureHeight + 25, {
            columns: 1,
            columnGap: 0,
            height: 40,
            width: lineSize,
            align: "center",
        });



    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(10)
        .fill("#021c27")
        .text("Yaamini Shahini", startLine3, signatureHeight + 10, {
            columns: 1,
            columnGap: 0,
            height: 40,
            width: lineSize,
            align: "center",
        });

    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(10)
        .fill("#021c27")
        .text(`HR MANAGER, XcitEducation
        `, startLine3, signatureHeight + 25, {
            columns: 1,
            columnGap: 0,
            height: 40,
            width: lineSize,
            align: "center",
        });
    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(10)
        .fill("#021c27")
        .text(`id : ${certiId}`, 150, 505, {
            align: "left",
        });
    // GENERATE QR code 
    const generateQR = async text => {
        try {

            const ans = await QRCode.toDataURL(text);
            return ans
        } catch (err) {
            console.log(err);
            return 0;
        }
    }
    const qr = await generateQR(`validate-your-certificate.xcitedu.com/${certiId}`);
    // console.log("qr", qr);
    // const logo = await fetchImage("https://i.imgur.com/2ff9bM7.png");
    doc.image(qr, 40, 485, {
        fit: [70, 70],
        align: 'center',
        valign: 'center'
    });
    jumpLine(doc, 6);

    // Validation link
    // const link = "https://validate-your-certificate.hello/validation-code-here";

    // const linkWidth = doc.widthOfString(link);
    // const linkHeight = doc.currentLineHeight();

    // doc
    //     .underline(doc.page.width / 2 - linkWidth / 2, 448, linkWidth, linkHeight, {
    //         color: "#021c27",
    //     })
    //     .link(doc.page.width / 2 - linkWidth / 2, 448, linkWidth, linkHeight, link);

    // doc
    //     .font("fonts/NotoSansJP-Light.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text(link, doc.page.width / 2 - linkWidth / 2, 448, linkWidth, linkHeight);

    // // Footer
    const bottomHeight = doc.page.height - 100;

    // doc.image("images/qr.png", doc.page.width / 2 - 30, bottomHeight, {
    //     fit: [60, 60],
    // });

    doc.fill('#FFF').stroke();
    doc.fontSize(11);
    doc.text("careers@xcitedu.com | XcitEducation Worldwide", 315, 565, { lineBreak: false });
    doc.end();

    //  Mail
    const output = `
          <h2>Hi ${name}, Thankyou for attending the ${sessiontype} on ${title} by XcitEducation conducted on ${date}</h2>
        <p>Please find your Certificate of participation below.</p>
        <h3>Your Details:</h3>
        <ul>
          <li>Name : ${name}</li>
          <li>Email : ${email}</li>
          <li>Event : ${sessiontype} on ${title}</li>
          <li>Date : ${date}</li>
        </ul>
        <p>We wish you All the Best for your bright future!</p>
        <p></p>
        <p>Regards</p>
        <p>Team XcitEducation</p>
      `;
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: "certificates.xcite@gmail.com", // generated ethereal user
            pass: "Rishabh@9293", // generated ethereal password
        },
        // If on localhost
        tls: {
            rejectUnauthorized: false,
        },
        service: "gmail",
    });

    //   // send mail with defined transport object
    let mailOptions = {
        // from: '"Nodemailer Testing" <raj.sanghavi1@svkmmumbai.onmicrosoft.com>', // sender address
        from: "certificates.xcite@gmail.com",
        to: `${email}`, // list of receivers
        subject: "Certificate Of Participation", // Subject line
        // text: "Hello world?", // plain text body
        // html: "<b>Hello world?</b>", // html body
        html: output,
        attachments: [
            {
                filename: `${name}_${title}_participation_certificate.pdf`,
                path: `certificates\\participation\\${name}_${title}_participation_certificate.pdf`
            },
        ],
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
        } else {
            console.log("Message of participation sent: %s", info.messageId);
            console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
            res.status(200).json({
                success: true,
                emailSuccess: true,
                data: req.body,
            });
        }
    });
};

// generatePDF("raj", "REACT COURSE");
module.exports = generateParticipationPdf;