const PDFDocument = require("pdfkit");
const fs = require("fs");
const nodemailer = require("nodemailer");
const axios = require("axios")
const QRCode = require('qrcode');

const generateLOR = async (certiId, name, email, domain, gender, hrsignurl, hrname, hrposition, date1, date2) => {
    const doc = new PDFDocument({
        layout: "portrait",
        size: "A4",
    });
    const fname = name.split(" ")[0]
    const today = new Date();
    const date = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear();
    // Helper to move to next line
    function jumpLine(doc, lines) {
        for (let index = 0; index < lines; index++) {
            doc.moveDown();
        }
    }
    // const url = "https://i.ibb.co/RgPxFNt/nancy.jpg"
    // hrsignimage = fetchImage("https://i.ibb.co/RgPxFNt/nancy.jpg");
    // async function fetchImage(url) {
    //     const image = await axios
    //         .get(url, {
    //             responseType: 'arraybuffer'
    //         })
    //     return image.data;
    // }

    doc.pipe(fs.createWriteStream(`certificates/LOR/${name}_${domain}_LOR.pdf`));

    // doc.rect(0, 0, doc.page.width, doc.page.height).fill("#fff");

    doc.fontSize(10);

    // Margin
    const distanceMargin = 18;

    // doc
    //     .fillAndStroke("#9d0000")
    //     .lineWidth(37)
    //     .lineJoin("miter")
    //     .rect(
    //         distanceMargin,
    //         distanceMargin,
    //         doc.page.width - distanceMargin * 2,
    //         doc.page.height - distanceMargin * 2
    //     )
    //     .stroke();

    // Header
    const maxWidth = 140;
    const maxHeight = 70;

    // doc.image("images/winners.png", doc.page.width / 2 - maxWidth / 2, 60, {
    //     fit: [maxWidth, maxHeight],
    //     align: "center",
    // });

    // jumpLine(doc, 5);

    // doc
    //     .font("fonts/NotoSansJP-Light.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text("Super Course for Awesomes", {
    //         align: "center",
    //     });

    jumpLine(doc, 2);

    // Content

    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(20)
        .fill("#021c27")
        .text(`XcitEducation 
Worldwide

`, 50, 50, {
            align: "left",
        });
    //     doc
    //         .font("fonts/NotoSansJP-Regular.otf")
    //         .fontSize(9)
    //         .fill("#021c27")
    //         .text(`CIN:U72900DL2020PTC372953

    // `, {
    //             align: "left",
    //         });
    // doc
    //     // .font("fonts/NotoSansJP-Regular.otf")
    //     .fontSize(9)
    //     // .fill("#021c27")
    //     .text(`CIN:U72900DL2020PTC372953
    //     `, {
    //         align: "left",
    //     });
    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(11)
        .fill("#021c27")
        .text("LETTER OF RECOMMENDATION", {
            align: "center",
        });

    jumpLine(doc, 1);

    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(10)
        .fill("#021c27")
        .text(`Date: ${date}`, {
            align: "right",
        });

    jumpLine(doc, 2);

    // doc
    //     .font("fonts/NotoSansJP-Bold.otf")
    //     .fontSize(24)
    //     .fill("#021c27")
    //     .text(`${name}`, {
    //         align: "center",
    //     });

    jumpLine(doc, 1);
    const months = {
        0: "January",
        1: "February",
        2: "March",
        3: "April",
        4: "May",
        5: "June",
        6: "July",
        7: "August",
        8: "September",
        9: "October",
        10: "November",
        11: "December",
    };
    const body2 = `${fname} is an inquisitive individual, who over his time with us, carried out his tasks with utmost dedication and motivation. These traits were consistent in all the ${domain} projects that he undertook in various segments in majorly contributing to the open-source community, for students coming from poorest section in general. His enthusiasm, coupled  with his hardwork, ensured thoroughness in his work. Over the course, he displayed the skills necessary for professional success including diligence, analytical thinking, eagerness to learn, as well as being active in dicussions and contributing to ideas.
                
We wish him all the very best for his future endeavors and would be pleased to be a reference 
for him, as and when the opportunity arises.`

    const body = gender === "male" ?
        `
        ${fname} is an inquisitive individual, who over his time with us, carried out his tasks with utmost dedication and motivation. These traits were consistent in all the ${domain} projects that he undertook in various segments in majorly contributing to the open-source community, for students coming from poorest section in general. His enthusiasm, coupled with his hardwork, ensured thoroughness in his work.
                       
Over the course, he displayed the skills necessary for professional success including diligence, analytical thinking, eagerness to learn, as well as being active in dicussions and contributing to ideas.
                       
We wish him all the very best for his future endeavors and would be pleased to be a reference for him, as and when the opportunity arises.
`
        : `
        ${fname} is an inquisitive individual, who over her time with us, carried out her tasks with utmost dedication and motivation. These traits were consistent in all the ${domain} projects that she undertook in various segments in majorly contributing to the open-source community, for students coming from poorest section in general. Her enthusiasm, coupled with her hardwork, ensured thoroughness in her work.
                   
        Over the course, she displayed the skills necessary for professional success including diligence, analytical thinking, eagerness to learn, as well as being active in dicussions and contributing to ideas.
                           
        We wish her all the very best for his future endeavors and would be pleased to be a reference for her, as and when the opportunity arises.
    `;
    // 
    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(10)
        .fill("#021c27")
        .text(
            // `has successfully completed the ${course} on ${new Date(
            //   Date.now()
            // ).toLocaleDateString()}.`
            `${name}
${domain} Intern
${date1} to ${date2}
`,
            {
                align: "left",
            }
        );
    doc
        .font("fonts/NotoSansJP-Light.otf")
        .fontSize(10)
        .fill("#021c27")
        .text(`${body}
        `,
            {
                align: "justify",
            }
        );
    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(10)
        .fill("#021c27")
        .text("Sincerely, ",
            {
                align: "left",
            });
    //     doc
    //         // .moveTo(200, 450)
    //         // .lineTo(200, 450)
    //         .stroke()
    //         // .image("images/nancy.jpeg", {
    //         //     fit: [maxWidth, maxHeight],
    //         //     align: "left",
    //         // })
    //         // .image("images/nancy.jpeg", {
    //         //     fit: [maxWidth, maxHeight],
    //         //     align: "left",
    //         // })
    //         .text(`Rishabh Ranjan
    // Founder and CEO
    //         `)
    async function fetchImage(src) {
        const image = await axios
            .get(src, {
                responseType: 'arraybuffer'
            })
        return image.data;
    }
    const sign = await fetchImage(hrsignurl);
    doc
        // .moveTo(200, 450)
        // .lineTo(200, 450)
        .stroke()
        // .image("images/nancy.jpeg", {
        //     fit: [maxWidth, maxHeight],
        //     align: "left",
        // })
        .image(sign, {
            fit: [maxWidth, maxHeight],
            align: "left",
        })
        .text(`${hrname}
${hrposition}

`)
    doc
        .text(`contact@xcitedu.com
                www.xcitedu.com

                `, {
            align: "right"
        })

    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(9)
        .fill("#021c27")
        .text(`certificate id: ${certiId}`, {
            align: "left",
        });
    doc
        .font("fonts/NotoSansJP-Regular.otf")
        .fontSize(9)
        .fill("#021c27")
        .text(`CIN : U72900DL2020PTC372953
        `, {
            align: "left",
        });
    // GENERATE QR code 
    const generateQR = async text => {
        try {

            const ans = await QRCode.toDataURL(text);
            return ans
        } catch (err) {
            console.log(err);
            return 0;
        }
    }
    const qr = await generateQR(`validate-your-certificate.xcitedu.com/${certiId}`);
    // console.log("qr", qr);
    // const logo = await fetchImage("https://i.imgur.com/2ff9bM7.png");
    doc.image(qr, {
        fit: [70, 70],
        align: 'center',
        valign: 'center'
    });
    jumpLine(doc, 7);

    doc.lineWidth(0);

    // Signatures
    const lineSize = 154;
    const signatureHeight = 450;

    doc.fillAndStroke("#9d0000");
    doc.strokeOpacity(0.2);

    const startLine1 = 208;
    const endLine1 = 198 + lineSize;
    // doc
    //     .moveTo(startLine1, signatureHeight)
    //     .lineTo(endLine1, signatureHeight)
    //     .stroke();
    doc.image("images/xcitedulogo.jpg", startLine1 + 290, 50, {
        // fit: [100, 100],
        // align: "left",
        height: 50,
        width: 50,
    });

    // doc.image("images/nancy.jpeg", startLine1 + 20, 370, {
    //     fit: [maxWidth, maxHeight],
    //     align: "left",
    // });
    // doc.image("images/yaamini1.jpeg", startLine1 + 330, 370, {
    //     fit: [300, 100],
    //     align: "left",
    // });

    const startLine2 = endLine1;
    const endLine2 = startLine2 + lineSize;
    // doc
    //   .moveTo(startLine2, signatureHeight)
    //   .lineTo(endLine2, signatureHeight)
    //   .stroke();

    // const startLine3 = endLine2;
    // const endLine3 = startLine3 + lineSize;
    // doc
    // .moveTo(startLine3, signatureHeight)
    // .lineTo(endLine3, signatureHeight)
    // .stroke();

    // doc
    //     .font("fonts/NotoSansJP-Regular.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text("Nancy", startLine1, signatureHeight + 10, {
    //         columns: 1,
    //         columnGap: 0,
    //         height: 40,
    //         width: lineSize,
    //         align: "center",
    //     });
    // doc
    //     .font("fonts/NotoSansJP-Light.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text("HR HEAD, XcitEducation", startLine1, signatureHeight + 25, {
    //         columns: 1,
    //         columnGap: 0,
    //         height: 40,
    //         width: lineSize,
    //         align: "center",
    //     });



    // doc
    //     .font("fonts/NotoSansJP-Regular.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text("Yaamini Shahini", startLine3, signatureHeight + 10, {
    //         columns: 1,
    //         columnGap: 0,
    //         height: 40,
    //         width: lineSize,
    //         align: "center",
    //     });

    // doc
    //     .font("fonts/NotoSansJP-Light.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text("HR MANAGER, XcitEducation", startLine3, signatureHeight + 25, {
    //         columns: 1,
    //         columnGap: 0,
    //         height: 40,
    //         width: lineSize,
    //         align: "center",
    //     });

    // doc
    //     .font("fonts/NotoSansJP-Regular.otf")
    //     .fontSize(10)
    //     .fill("black")
    //     .text("careers@xcitedu.com  XcitEducation Worldwide, Delhi", 200, 740)
    // .lineBreak(false)
    // .align("center")

    doc.moveTo(0, 835)


        .lineTo(800, 835)
        .lineWidth(30)
        .strokeOpacity(1)
        .stroke("#9d0000")

    doc.fill('#FFF').stroke();
    doc.fontSize(10);
    doc.text("careers@xcitedu.com | XcitEducation Worldwide", 193, 823, { lineBreak: false });

    jumpLine(doc, 6);

    // Validation link
    // const link = "https://validate-your-certificate.hello/validation-code-here";

    // const linkWidth = doc.widthOfString(link);
    // const linkHeight = doc.currentLineHeight();

    // doc
    //     .underline(doc.page.width / 2 - linkWidth / 2, 448, linkWidth, linkHeight, {
    //         color: "#021c27",
    //     })
    //     .link(doc.page.width / 2 - linkWidth / 2, 448, linkWidth, linkHeight, link);

    // doc
    //     .font("fonts/NotoSansJP-Light.otf")
    //     .fontSize(10)
    //     .fill("#021c27")
    //     .text(link, doc.page.width / 2 - linkWidth / 2, 448, linkWidth, linkHeight);

    // // Footer
    const bottomHeight = doc.page.height - 100;

    // doc.image("images/qr.png", doc.page.width / 2 - 30, bottomHeight, {
    //     fit: [60, 60],
    // });

    doc.end();

    //  Mail
    const output = `
          <h2>Hi ${name}, you have performed very well as a ${domain} intern in XcitEducation.</h2>
        <p>Please find your Letter of Recommendation below.</p>
        <h3>Your Details:</h3>
        <ul>
          <li>Name : ${name}</li>
          <li>Email : ${email}</li>
          <li>domain : ${domain}</li>
          <li>Date : ${date}</li>
        </ul>
        <p>We wish you All the Best for your bright future!</p>
        <p></p>
        <p>Regards</p>
        <p>Team XcitEducation</p>
      `;
    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        secure: false, // true for 465, false for other ports
        auth: {
            user: "certificates.xcite@gmail.com", // generated ethereal user
            pass: "Rishabh@9293", // generated ethereal password
        },
        // If on localhost
        tls: {
            rejectUnauthorized: false,
        },
        service: "gmail",
    });

    //   // send mail with defined transport object
    let mailOptions = {
        // from: '"Nodemailer Testing" <raj.sanghavi1@svkmmumbai.onmicrosoft.com>', // sender address
        from: "certifcates.xcite@gmail.com",
        to: `${email}`, // list of receivers
        subject: "Letter of Recommendation", // Subject line
        // text: "Hello world?", // plain text body
        // html: "<b>Hello world?</b>", // html body
        html: output,
        attachments: [
            {
                filename: `${name}_${domain}_LOR.pdf`,
                path: `certificates\\LOR\\${name}_${domain}_LOR.pdf`
            },
        ],
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
        } else {
            console.log("Message of LOR sent: %s", info.messageId);
            console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
            res.status(200).json({
                success: true,
                emailSuccess: true,
                data: req.body,
            });
        }
    });
};

// generatePDF("raj", "REACT COURSE");
module.exports = generateLOR;